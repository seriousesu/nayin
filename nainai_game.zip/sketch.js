function setup() {
  createCanvas(windowWidth, windowHeight);
  textSize(32);
}

function draw() {
  background(220);
  text("奶奶的小游戏加载成功！", 50, 100);
}
